<?php
/**
 * Plugin Name: Pickit
 * Description: Módulo de Pickit para WooCommerce.
 * Version: 1.0.0
 * Author: VDFactory
 *
 * @package Pickit
 */

function your_prefix_activate(){
    register_uninstall_hook( PICKIT_URL, 'borrarTablasSql' );
}
register_activation_hook( PICKIT_URL, 'your_prefix_activate' );
 
// And here goes the uninstallation function:
function borrarTablasSql(){
    global $wpdb;

    $tablename = $wpdb->prefix . "woocommerce_pickit_global";
    $wpdb->query("DROP TABLE IF EXISTS $tablename");

    $tablename = $wpdb->prefix . "woocommerce_pickit_order";
    $wpdb->query("DROP TABLE IF EXISTS $tablename");
}