<?php
/**
 * Plugin Name: Pickit
 * Description: Módulo de Pickit para WooCommerce.
 * Version: 1.0.0
 * Author: VDFactory
 *
 * @package Pickit
 */
include_once PICKIT_PATH . 'includes/pkt-class-utilities.php';

// TABLE EN MY_ACCOUNT (USUARIO) | Columna Tracking
add_filter( 'woocommerce_account_orders_columns', 'agregarColumnaTrackingUsuario', 10, 1 );
function agregarColumnaTrackingUsuario( $columns ){
    $new_columns = array();

    foreach ( $columns as $key => $name ) {

        $new_columns[ $key ] = $name;

        // add ship-to after order status column
        if ( 'order-actions' === $key ) {  //this is the line!
            $new_columns['pickit-tracking'] = __( 'Pickit - Tracking URL', 'woocommerce' );
        }
    }
    return $new_columns;
}

add_action( 'woocommerce_my_account_my_orders_column_pickit-tracking', 'agregarColumnaTrackingUsuarioContenido' );
function agregarColumnaTrackingUsuarioContenido( $order ) { 
    // ORDER ID (INT)
    $orderId = intval($order->get_order_number());
    $tracking = PKT_UTILITIES::consultarTracking($orderId);
    if ($tracking)
        echo "<a href='$tracking' target='_blank'>Seguimiento</a>";
}

 
// TABLE EN WooCommerce -> Orders (ADMIN) | Columna Etiqueta
add_filter( 'manage_edit-shop_order_columns', 'agregarColumnaOrderAdminEtiqueta' );
function agregarColumnaOrderAdminEtiqueta( $columns ) {
    $columns['pickit_etiqueta'] = 'Pickit - Etiqueta';
    return $columns;
}
 
add_action( 'manage_shop_order_posts_custom_column', 'agregarColumnaOrderAdminEtiquetaContenido' );
function agregarColumnaOrderAdminEtiquetaContenido( $column ) {
    global $post;
    if($column == "pickit_etiqueta"){
        // ORDER ID (INT) => | $post->ID |
        $orderId = $post->ID;
        $etiqueta = PKT_UTILITIES::consultarEtiqueta($orderId);
        if ($etiqueta)
            echo "<a href='$etiqueta' target='_blank'>Etiqueta</a>";
        else {
            $transaccionId = PKT_UTILITIES::consultarTransaccionId($orderId);
            $etiqueta = PKT_UTILITIES::obtenerEtiqueta($transaccionId);
            $responseCode = $etiqueta["Status"]["Code"];
            if ($responseCode == "200"){

                $urlEtiqueta = $etiqueta["Response"]["UrlEtiqueta"][0];
                echo "<a href='$urlEtiqueta' target='_blank'>Etiqueta</a>";
                PKT_UTILITIES::insertarEtiqueta($urlEtiqueta, $transaccionId);
            }
        }
    }
}

//  TABLE EN WooCommerce -> Orders (ADMIN) | Columna Estado Actual
add_filter( 'manage_edit-shop_order_columns', 'agregarColumnaOrderAdminEstadoActual' );
function agregarColumnaOrderAdminEstadoActual( $columns ) {
    $columns['pickit_estado_actual'] = 'Pickit - Estado Actual';
    return $columns;
}
 
add_action( 'manage_shop_order_posts_custom_column', 'agregarColumnaOrderAdminEstadoActualContenido' );
function agregarColumnaOrderAdminEstadoActualContenido( $column ) {
    global $post;
    if($column == "pickit_estado_actual"){
        // ORDER ID (INT) => | $post->ID |
        $orderId = $post->ID;
        $estadoactual = PKT_UTILITIES::consultarEstadoActual($orderId);
        if ( $estadoactual == 1)
            echo "En retailer.";
        elseif ( $estadoactual == 2)
            echo "Disponible para retiro.";
    }
}


// BULK ACTION
//  Agrega la acción nueva a la lista de Admin -> WooCommerce -> Orders
add_filter( 'bulk_actions-edit-shop_order', 'cambiar_estado_bulk_action', 20, 1 );
function cambiar_estado_bulk_action( $actions ) {
    $actions['cambiar_estado'] = __( 'Pickit - Cambiar a disponible para colecta', 'woocommerce' );
    return $actions;
}

//  Realiza la acción del Bulk Action
add_filter( 'handle_bulk_actions-edit-shop_order', 'cambiar_estado_bulk_action_handle', 10, 3 );
function cambiar_estado_bulk_action_handle( $redirect_to, $action, $post_ids ) {
    if ( $action !== 'cambiar_estado' )
        return $redirect_to; // Exit
        
    $processed_ids = array();
    $requestsWs = array();

    foreach($post_ids as $id){
        $estadoActualId = PKT_UTILITIES::consultarEstadoActual($id);
        if ($estadoActualId == 1){
            $requestWs = PKT_UTILITIES::cambiarEstadoActualWs($id);
            $requestDb = PKT_UTILITIES::cambiarEstadoActualDb($id);
            $processed_ids[] = $id;
        }
    }

    if (empty($processed_ids))
        $ningunoCambioEstado = 1;

    return $redirect_to = add_query_arg( array(
        'processed_ids'     => $processed_ids,
        'cambio_estado'     => $ningunoCambioEstado,
    ), $redirect_to );
}

//  Muestra un mensaje de confirmación al usuario.
add_action( 'admin_notices', 'cambiar_estado_bulk_action_admin_notice' );
function cambiar_estado_bulk_action_admin_notice() {
    $count = count( $_REQUEST['processed_ids'] );
    $ningunoCambioEstado = $_REQUEST['cambio_estado'];

    if( $count == 1 )
        echo("<div id='message' class='updated fade'><p>Se cambió el estado de 1 orden.</p></div>");
    else if ( $count > 1)
        echo("<div id='message' class='updated fade'><p>Se cambió el estado de $count órdenes.</p></div>");
    else if ( $ningunoCambioEstado == 1 )
        echo("<div id='message' class='error updated fade'><p>No se cambió el estado de ninguna orden.</p></div>");
}

// Muestra un mensaje cuando no hay Puntos Pickits disponibles para el código postal.
add_action( 'woocommerce_before_shipping_calculator', 'agregoLabelNoHayPuntos' );
function agregoLabelNoHayPuntos() {
    session_start();
    if ( WC()->session->get( "noHayPuntos" ) && !WC()->session->get( "noSeIngresoCodigoPostal" ))
        echo "<label> No hay Puntos Pickit disponibles para tu código postal. </label>";
    else
        echo "";
}

// Muestra un mensaje cuando no hay Puntos Pickits disponibles para el código postal.
add_action( 'woocommerce_before_shipping_calculator', 'agregoLabelIngreseCodigoPostal' );
function agregoLabelIngreseCodigoPostal() {
    session_start();
    //if ($_SESSION["noSeIngresoCodigoPostal"]) {

    if ( WC()->session->get( "noSeIngresoCodigoPostal" ) ) {
        echo "<label> Ingrese su código postal para ver los envíos Pickit disponibles. </label>";
    }
    else {
        echo "";
    }
}