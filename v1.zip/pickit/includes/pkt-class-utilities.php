<?php
/**
 * Plugin Name: Pickit
 * Description: Módulo de Pickit para WooCommerce.
 * Version: 1.0.0
 * Author: VDFactory
 *
 * @package Pickit
 */

/**
 * Pickit Functions Class
 */
class PKT_UTILITIES {

    // Devuelve el tipo de envío disponible de la base de datos.
    public function obtenerTipoDeEnvioDisponible(){
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_ship_type = ($wpdb->get_results(
            "SELECT pickit_ship_type FROM $table"
        ))[0]->pickit_ship_type;
        
        return $pickit_ship_type;
    }

    // Devuelve el ID de carrier del método a domicilio.
    public function obtenerIdMetodoDomicilio(){
        return "pickit_domicilio_ship";
    }

    // Devuelve los IDs de carrier del método de cada punto Pickit.
    public function obtenerIdMetodoPunto(){
        $idPuntos[] = "pickit_punto_1";
        $idPuntos[] = "pickit_punto_2";
        $idPuntos[] = "pickit_punto_3";
        $idPuntos[] = "pickit_punto_4";
        $idPuntos[] = "pickit_punto_5";
        return $idPuntos;
    }

    // Devuelve el TokenId de la base de datos.
    public function obtenerTokenId() {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_token_id = ($wpdb->get_results(
            "SELECT pickit_token_id FROM $table"
        ))[0]->pickit_token_id;

        return $pickit_token_id;
    }

    // Devuelve la Apikey del WebApp la base de datos.
    public function obtenerApikey() {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_apikey = ($wpdb->get_results(
            "SELECT pickit_apikey_webapp FROM $table"
        ))[0]->pickit_apikey_webapp;
        
        return $pickit_apikey;
    }

    // Devuelve la URL del Web Service de la base de datos.
    // Depende del valor de pickit_testing_mode
    // (Si el modo de testeo está habilitado, devuelve la URL de testeo.)
    public function obtenerUrlWS() {

        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_testing_mode = ($wpdb->get_results(
            "SELECT pickit_testing_mode FROM $table"
        ))[0]->pickit_testing_mode;

        //Si el modo de testeo está deshabilitado.
        if ($pickit_testing_mode == 0){

            global $wpdb;
            $table = $wpdb->prefix . 'woocommerce_pickit_global';

            $pickit_urlws = $wpdb->get_results(
                "SELECT pickit_url_webservice FROM $table"
            );

            //Retorna el URL del Web Service.
            return $pickit_urlws[0]->pickit_url_webservice;

        } else {

            global $wpdb;
            $table = $wpdb->prefix . 'woocommerce_pickit_global';

            $pickit_urlwst = $wpdb->get_results(
                "SELECT pickit_url_webservice_test FROM $table"
            );

            //Retorna el URL de Testing del Web Service.
            return $pickit_urlwst[0]->pickit_url_webservice_test;
        }
    }

    // Devuelve el tipo de Precio de envío a domicilio de la base de datos.
    public function obtenerTipoPrecioEnvioDom() {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_ship_price_opt_dom = ($wpdb->get_results(
            "SELECT pickit_ship_price_opt_dom FROM $table"
        ))[0]->pickit_ship_price_opt_dom;

        return $pickit_ship_price_opt_dom;
    }

    // Devuelve el Precio Fijo de envío a domicilio de la base de datos.
    public function obtenerPrecioFijoEnvioDom() {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_ship_price_fijo_dom = ($wpdb->get_results(
            "SELECT pickit_ship_price_fijo_dom FROM $table"
        ))[0]->pickit_ship_price_fijo_dom;

        return (float)$pickit_ship_price_fijo_dom;
    }

    // Devuelve el porcentaje personalizado del precio de envío a domicilio de la base de datos.
    public function obtenerPrecioPorcentualEnvioDom() {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_ship_price_porcentual_dom = ($wpdb->get_results(
            "SELECT pickit_ship_price_porcentual_dom FROM $table"
        ))[0]->pickit_ship_price_porcentual_dom;

        return ($pickit_ship_price_porcentual_dom / 100);
    }

    // Devuelve el tipo de Precio de envío a punto de la base de datos.
    public function obtenerTipoPrecioEnvioPunto() {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_ship_price_opt_punto = ($wpdb->get_results(
            "SELECT pickit_ship_price_opt_punto FROM $table"
        ))[0]->pickit_ship_price_opt_punto;

        return $pickit_ship_price_opt_punto;
    }

    // Devuelve el Precio Fijo de envío a punto de la base de datos.
    public function obtenerPrecioFijoEnvioPunto() {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_ship_price_fijo_punto = ($wpdb->get_results(
            "SELECT pickit_ship_price_fijo_punto FROM $table"
        ))[0]->pickit_ship_price_fijo_punto;

        return (float)$pickit_ship_price_fijo_punto;
    }

    // Devuelve el porcentaje personalizado del precio de envío a punto de la base de datos.
    public function obtenerPrecioPorcentualEnvioPunto() {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_ship_price_porcentual_punto = ($wpdb->get_results(
            "SELECT pickit_ship_price_porcentual_punto FROM $table"
        ))[0]->pickit_ship_price_porcentual_punto;

        return ($pickit_ship_price_porcentual_punto / 100);
    }

    // Devuelve el nombre a mostrar del envío a domicilio de la base de datos.
    public function obtenerTitleDom(){
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_titledom = ($wpdb->get_results(
            "SELECT pickit_titledom FROM $table"
        ))[0]->pickit_titledom;

        return $pickit_titledom;
    }

    // Devuelve el estado inicial de la base de datos.
    public function obtenerEstadoInicial(){
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_estado_inicial = ($wpdb->get_results(
            "SELECT pickit_estado_inicial FROM $table"
        ))[0]->pickit_estado_inicial;

        return (int)$pickit_estado_inicial;
    }

    // Devuelve el tipo del peso de producto (kg, g, libra) de la base de datos.
    public function obtenerTipoPesoProducto(){
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_product_weight = ($wpdb->get_results(
            "SELECT pickit_product_weight FROM $table"
        ))[0]->pickit_product_weight;

        return $pickit_product_weight;
    }

    // Devuelve el tipo de las dimensiones del producto (cm, m) de la base de datos.
    public function obtenerTipoDimensionProducto(){
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_product_dim = ($wpdb->get_results(
            "SELECT pickit_product_dim FROM $table"
        ))[0]->pickit_product_dim;

        return $pickit_product_dim;
    }
    
    //Devuelve el Id del tipo de precio fijo.
    public function obtenerIdTipoPrecioFijo(){
        return 1;
    } 

    //Devuelve el Id del tipo de precio porcentual.
    public function obtenerIdTipoPrecioPorcentual(){
        return 2;
    }  
     
    //Devuelve el Id del tipo de peso kilogramo.
    public function obtenerIdTipoPesoKilo(){
        return 0;
    }

    //Devuelve el Id del tipo de peso libra.
    public function obtenerIdTipoPesoLibra(){
        return 2;        
    }

    //Devuelve el Id del tipo de dimensión centímetro.
    public function obtenerIdTipoDimensionCentimetro(){
        return 0;        
    }

    // Devuelve el ID del tipo de operación de domicilio.
    public function obtenerOperationTypeDomicilio(){
        return 2;        
    }

    // Devuelve el ID del tipo de operación de punto.
    public function obtenerOperationTypePunto(){
        return 1;        
    }

    // Devuelve el tipo de imposición de la base de datos.
    public function obtenerTipoImposicion(){
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_global';

        $pickit_imposition_available = ($wpdb->get_results(
            "SELECT pickit_imposition_available FROM $table"
        ))[0]->pickit_imposition_available;

        return $pickit_imposition_available;
    }

    // Inserta en la tabla de "pickit_order".
    // pickit_orden_impuesta:
    // 0 => No impuesta
    // 1 => Impuesta
    public function insertarTablaOrderImpuesta ( $orderId, $transaccionId, $urlEtiqueta, $urlTracking, $estadoInicial ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'woocommerce_pickit_order';

        $wpdb->insert(
            $table_name,
            array(
                'pickit_wc_order_id' => $orderId, 
                'pickit_transaccion_id' => $transaccionId,
                'pickit_etiqueta' => $urlEtiqueta,
                'pickit_seguimiento' => $urlTracking,
                'pickit_estado_actual' => $estadoInicial,
                'pickit_orden_impuesta' => 1
            )
        );
    }

    // Inserta en la tabla de "pickit_order".
    public function insertarTablaOrderNoImpuesta ( $orderId ) {
        global $wpdb;

        $table_name = $wpdb->prefix . 'woocommerce_pickit_order';

        $wpdb->insert(
            $table_name,
            array(
                'pickit_wc_order_id' => $orderId,
                'pickit_orden_impuesta' => 0
            )
        );
    }

    // Inserta sólo la etiqueta en la tabla de "pickit_order" (Al transaccionId correspondiente).
    public function insertarEtiqueta($urlEtiqueta, $transaccionId){
        global $wpdb;

        $table = $wpdb->prefix . 'woocommerce_pickit_order';

        $wpdb->query( $wpdb->prepare(
            "UPDATE $table SET pickit_etiqueta = %s WHERE pickit_transaccion_id = %d",
            $urlEtiqueta, $transaccionId)
        );
    }

    // Devuelve la etiqueta de la base de datos, correspondiente al orderId.
    public function consultarEtiqueta($orderId){
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_order';

        $pickit_etiqueta = ($wpdb->get_results(
            "SELECT pickit_etiqueta FROM $table WHERE (pickit_wc_order_id = $orderId)"
        ))[0]->pickit_etiqueta;

        return $pickit_etiqueta;
    }

    // Devuelve la URL de Tracking de la base de datos.
    public function consultarTracking( $orderId ) {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_order';

        $pickit_seguimiento = ($wpdb->get_results(
            "SELECT pickit_seguimiento FROM $table WHERE (pickit_wc_order_id = $orderId)"
        ))[0]->pickit_seguimiento;

        return $pickit_seguimiento;
    }

    // Devuelve el estado actual de la tabla "order" correspondiente al orderId.
    public function consultarEstadoActual( $orderId ) {
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_order';

        $pickit_estado_actual = ($wpdb->get_results(
            "SELECT pickit_estado_actual FROM $table WHERE (pickit_wc_order_id = $orderId)"
        ))[0]->pickit_estado_actual;

        return $pickit_estado_actual;
    }

    // Devuelve el ID de transacción de la base de datos.
    public function consultarTransaccionId($orderId){
        global $wpdb;
        $table = $wpdb->prefix . 'woocommerce_pickit_order';

        $pickit_transaccion_id = ($wpdb->get_results(
            "SELECT pickit_transaccion_id FROM $table WHERE (pickit_wc_order_id = $orderId)"
        ))[0]->pickit_transaccion_id;

        return $pickit_transaccion_id;
    }

    // Cambia el estado actual de la base de datos de 1 a 2 de el registro asociado al ID de orden.
    public function cambiarEstadoActualDb($orderId){
        global $wpdb;

        $table = $wpdb->prefix . 'woocommerce_pickit_order';

        $request = $wpdb->query( $wpdb->prepare( "UPDATE $table SET pickit_estado_actual = %d WHERE pickit_wc_order_id = %d", 2, $orderId) );

        return $request;
    }

    // ---------- Empiezan las funciones de Web Service ---------- //

    // Función para generar request al Web Service de Pickit
    public function callPickitWs($data, $url) {
        $postdata = json_encode($data);
        
        $ch = curl_init();
        
		$pickit_url = PKT_UTILITIES::obtenerUrlWS();
        $pickit_apikey = PKT_UTILITIES::obtenerApikey();

        $requestUrl = $pickit_url . $url;
        
        curl_setopt($ch, CURLOPT_URL, $requestUrl);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type:application/json',
            "apiKey:$pickit_apikey"
        ));

        $outputJson = curl_exec($ch);
        $output = json_decode($outputJson, true);

        curl_close($ch);

        return $output;
    }
    // Función para generar request al Web Service V2.0 de Pickit
    public function callNewPickitWs($data, $url) {
        $postdata = json_encode($data);
        
        $ch = curl_init();
        
		$pickit_url = PKT_UTILITIES::obtenerUrlWS();
        $pickit_apikey = PKT_UTILITIES::obtenerApikey();
        $pickit_token_id = PKT_UTILITIES::obtenerTokenId();

        $requestUrl = $pickit_url . $url;
        
        curl_setopt($ch, CURLOPT_URL, $requestUrl);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type:application/json',
            "apiKey:$pickit_apikey",
            "token:$pickit_token_id"
        ));
        
        $outputJson = curl_exec($ch);
        $output = json_decode($outputJson, true);

        curl_close($ch);

        return $output;
    }

    // Devuelve la etiqueta del Web Service.
    public function obtenerEtiqueta($transaccionId){

        $dataEtiqueta = array(
            'transaccionId' => $transaccionId,
        );

        $urlEtiqueta = "/api/ObtenerEtiqueta";

        $requestEtiqueta = PKT_UTILITIES::callPickitWs($dataEtiqueta, $urlEtiqueta);

        return $requestEtiqueta;
    }

    // Cambia el estado de 1 a 2 de la orden del ID transacción enviado.
    public function cambiarEstadoInicialWs ( $orderId ) {

        $pickit_token_id = PKT_UTILITIES::obtenerTokenId();
        $transaccionId = PKT_UTILITIES::consultarTransaccionId($orderId);

        $dataCambiarEstado = array(
            "tokenId" => $pickit_token_id,
            "transaccionId" => $transaccionId
        );

        $urlCambiarEstado = "/api/DisponibleParaRetiro";

        $requestCambiarEstado = PKT_UTILITIES::callPickitWs($dataCambiarEstado, $urlCambiarEstado);

        return $requestCambiarEstado;
    }

    // Devuelve la cotización (A domicilio o a punto).
    public function obtenerCotizacion($package, $envio){

        $listaProductos = array();

        foreach ($package["contents"] as $prod => $value) {
            
            $_product = new WC_Product($value["product_id"]);

            $pprice = $_product->get_price();
            $pweight = $_product->get_weight();
            $plength = $_product->get_length();
            $pwidth = $_product->get_width();
            $pheight = $_product->get_height();
            $pname = $_product->get_name();
            $psku = $_product->get_sku();

            $tipoPesoProducto = PKT_UTILITIES::obtenerTipoPesoProducto();
            $tipoDimensionProducto = PKT_UTILITIES::obtenerTipoDimensionProducto();

            if ( $tipoPesoProducto == PKT_UTILITIES::obtenerIdTipoPesoKilo() )
                $pweight *= 1000;
            elseif ( $tipoPesoProducto == PKT_UTILITIES::obtenerIdTipoPesoLibra() )
                $pweight *= 453.5;

            $centimetro = PKT_UTILITIES::obtenerIdTipoDimensionCentimetro();

            $newProductToAdd = array(
                "name" => $pname,
                "weight" => array(
                    "amount" => $pweight ? (float)ceil($pweight) : 1,
                    "unit" => "g"
                ),
                "length" => array(
                    "amount" => $plength ? (float)$plength : 1,
                    "unit" => $tipoDimensionProducto == $centimetro ? "cm" : "m"
                ),
                "height" => array(
                    "amount" => $pheight ? (float)$pheight : 1,
                    "unit" => $tipoDimensionProducto == $centimetro ? "cm" : "m"
                ),
                "width" => array(
                    "amount" => $pwidth ? (float)$pwidth : 1,
                    "unit" => $tipoDimensionProducto == $centimetro ? "cm" : "m"
                ),
                "price" => $pprice ? (float)$pprice : 1,
                "sku" => $psku
            );
            array_push($listaProductos, $newProductToAdd);
        }       

        
        if(is_user_logged_in()){
            $customer = new WC_Customer($package["user"]["ID"]);
            $customerdata = $customer->get_data();
            
            $nombre = $customerdata["shipping"]["first_name"];
            $apellido = $customerdata["shipping"]["last_name"];
            $email = $customerdata["email"];
            $tel = $customerdata["billing"]["phone"];

            //$pais = $package["destination"]["country"];
            $provinciaId = $package["destination"]["state"];
            $codpost = $package["destination"]["postcode"];
            $ciudad = $package["destination"]["city"] == NULL ? "No especificado" : $package["destination"]["city"];
            $dir = $package["destination"]["address"];
            $dir2 = $package["destination"]["address_1"];
            $dir3 = $package["destination"]["address_2"];
        }
        
        global $woocommerce;
        if ( $woocommerce->customer->changes["shipping"]["postcode"] ) {
            $codpost = $woocommerce->customer->changes["shipping"]["postcode"];
            $ciudad = $woocommerce->customer->changes["shipping"]["city"] == NULL ? "No especificado" : $woocommerce->customer->changes["shipping"]["city"];
            $nombre = "Test";
            $apellido = "Test";
            $email = "test@test.com";
            $tel = "0000000000";
            $dir = "Test 1234";
            $provinciaId = "TEST";
        }

        $pickit_token_id = PKT_UTILITIES::obtenerTokenId();

        if ($envio["tipo"] == "domicilio")
            $dataCotPkt = array (
                "serviceType" => "PP",
                "workflowTag" => "dispatch",
                "operationType" => PKT_UTILITIES::obtenerOperationTypeDomicilio(),
                "retailer" => array(
                    "tokenId" => $pickit_token_id,
                ),
                "products" => $listaProductos,
                "sla" => array(
                    "id" => 1
                ),
                "customer" => array(
                    "name" => $nombre,
                    "lastName" => $apellido,
                    "pid" => 1,
                    "email" => $email,
                    "phone" => $tel,
                    "address" => array(
                        "postalCode" => $codpost,
                        "address" => $dir,
                        "city" => $ciudad,
                        "province" => $provinciaId
                    )
                ),
            );
        else if ($envio["tipo"] == "punto")
            $dataCotPkt = array (
                "serviceType" => "PP",
                "workflowTag" => "dispatch",
                "operationType" => PKT_UTILITIES::obtenerOperationTypePunto(),
                "retailer" => array(
                    "tokenId" => $pickit_token_id,
                ),
                "products" => $listaProductos,
                "sla" => array(
                    "id" => 1
                ),
                "customer" => array(
                    "name" => $nombre,
                    "lastName" => $apellido,
                    "pid" => 1,
                    "email" => $email,
                    "phone" => $tel,
                    "address" => array(
                        "postalCode" => $codpost,
                        "address" => $dir,
                        "city" => $ciudad,
                        "province" => $provinciaId
                    )
                ),
                "pointId" => $envio["idPunto"]
            );

        
        $urlCotPkt = "/apiV2/budget";
            
        $requestCotPkt = PKT_UTILITIES::callNewPickitWs($dataCotPkt, $urlCotPkt);
        
        return $requestCotPkt;
    }
    
    // Devuelve los puntos Pickit asociados al código postal.
    public function obtenerPuntos($postCode){

        //if(!is_user_logged_in()){
        global $woocommerce;
        if ( $woocommerce->customer->changes["shipping"]["postcode"] ){
            $postCode = $woocommerce->customer->changes["shipping"]["postcode"];
        }

        if (!$postCode)
            return;

        $ch = curl_init();

        $url = "/apiV2/map/point";
        
		$pickit_url = PKT_UTILITIES::obtenerUrlWS();
        $pickit_apikey = PKT_UTILITIES::obtenerApikey();
        $pickit_token_id = PKT_UTILITIES::obtenerTokenId();

        $requestUrl = $pickit_url . $url;
        
        $parameters = array (
            "filter.retailer.tokenId"   => $pickit_token_id,
            "filter.postalCode"         => $postCode,
            "orderBy"                   => "rnd"
        );
    
        $headers = array(
            'Content-Type:application/json',
            "apiKey:$pickit_apikey",
            "token:$pickit_token_id"
        );

        curl_setopt($ch, CURLOPT_URL, $requestUrl . '?' . http_build_query($parameters));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        
        $outputJson = curl_exec($ch);
        $output = json_decode($outputJson, true);

        curl_close($ch);

        return $output;
    }

    // Impone la transacción (A domicilio o a punto).
    public function imponerSimplificadoTransaccion ($orderId, $envio) {

        $order = new WC_Order($orderId);

        $billing = $order->get_data()["billing"];
        $shipping = $order->get_data()["shipping"];

        $nombre = $shipping["first_name"];
        $apellido = $shipping["last_name"];
        $dir = $shipping["address_1"];
        $ciudad = $shipping["city"];
        $provincia = $shipping["state"];
        $postcode = $shipping["postcode"];
        $pais = $shipping["country"];
        $email = $billing["email"];
        $phone = $billing["phone"];


        $orderProducts = $order->get_items();

        $listaProductos = array();
        foreach ($orderProducts as $ordProd => $prod) {
            $quantity = $prod->get_data()["quantity"];
            $prodId = $prod->get_data()["product_id"];
            $_product = new WC_Product($prodId);

            $pprice = $_product->get_price();
            $pweight = $_product->get_weight();
            $plength = $_product->get_length();
            $pwidth = $_product->get_width();
            $pheight = $_product->get_height();
            $pname = $_product->get_name();
            $psku = $_product->get_sku();

            $tipoPesoProducto = PKT_UTILITIES::obtenerTipoPesoProducto();
            $tipoDimensionProducto = PKT_UTILITIES::obtenerTipoDimensionProducto();
            $centimetro = PKT_UTILITIES::obtenerIdTipoDimensionCentimetro();

            if ( $tipoPesoProducto == PKT_UTILITIES::obtenerIdTipoPesoKilo() )
                $pweight *= 1000;
            elseif ( $tipoPesoProducto == PKT_UTILITIES::obtenerIdTipoPesoLibra() )
                $pweight *= 453.6;

            for($i=0;$i<$quantity;$i++){

                $newProductToAdd = array(
                    "name" => $pname,
                    "weight" => array(
                        "amount" => $pweight ? (float)ceil($pweight) : 1,
                        "unit" => "g"
                    ),
                    "length" => array(
                        "amount" => $plength ? (float)$plength : 1,
                        "unit" => $tipoDimensionProducto == $centimetro ? "cm" : "m"
                    ),
                    "height" => array(
                        "amount" => $pheight ? (float)$pheight : 1,
                        "unit" => $tipoDimensionProducto == $centimetro ? "cm" : "m"
                    ),
                    "width" => array(
                        "amount" => $pwidth ? (float)$pwidth : 1,
                        "unit" => $tipoDimensionProducto == $centimetro ? "cm" : "m"
                    ),
                    "price" => $pprice ? (float)$pprice : 1,
                    "sku" => $psku
                );
                array_push($listaProductos, $newProductToAdd);
            }
        }

        $pickit_token_id = PKT_UTILITIES::obtenerTokenId();
        $estado_inicial = PKT_UTILITIES::obtenerEstadoInicial();
        $pickit_apikey = PKT_UTILITIES::obtenerApikey();

        session_start();
        if ( $envio["tipo"] == "domicilio" )
            $dataImp = array(
                "budgetPetition" => array(
                    "serviceType" => "PP",
                    "workflowTag" => "dispatch",
                    "operationType" => PKT_UTILITIES::obtenerOperationTypeDomicilio(),
                    "retailer" => array(
                        "tokenId" => $pickit_token_id
                    ),
                    "products" => $listaProductos,
                    "sla" => array(
                        "id" => 1
                    ),
                    "customer" => array(
                        "name" => $nombre,
                        "lastName" => $apellido,
                        // DNI
                        "pid" => 11111111,
                        "email" => $email,
                        "phone" => $phone,
                        "address" => array(
                            "postalCode" => $postcode,
                            "address" => $dir,
                            "city" => $ciudad,
                            "province" => $provincia
                        )
                    ),
                ),
                "firstState" => $estado_inicial,
                "trakingInfo" => array(
                "order" => (string)$orderId
                //"shipment" => "string"
                ),
                "packageAmount" => 1
            );
        else if ( $envio["tipo"] == "punto" )
            $dataImp = array(
                "budgetPetition" => array(
                    "serviceType" => "PP",
                    "workflowTag" => "dispatch",
                    "operationType" => PKT_UTILITIES::obtenerOperationTypePunto(),
                    "retailer" => array(
                        "tokenId" => $pickit_token_id
                    ),
                    "products" => $listaProductos,
                    "sla" => array(
                        "id" => 1
                    ),
                    "customer" => array(
                        "name" => $nombre,
                        "lastName" => $apellido,
                        // DNI
                        "pid" => 11111111,
                        "email" => $email,
                        "phone" => $phone,
                        "address" => array(
                            "postalCode" => $postcode,
                            "address" => $dir,
                            "city" => $ciudad,
                            "province" => $provincia
                        )
                    ),
                    "pointId" => $envio["idPunto"]
                ),
                "firstState" => $estado_inicial,
                "trakingInfo" => array(
                    "order" => (string)$orderId
                ),
                "packageAmount" => 1
            );

        $urlImp = "/apiV2/transaction";

        $requestImp = PKT_UTILITIES::callNewPickitWs($dataImp, $urlImp);

        return $requestImp;
    }
}