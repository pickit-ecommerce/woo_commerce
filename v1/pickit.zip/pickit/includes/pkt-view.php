<?php
/**
 * Plugin Name: Pickit
 * Description: Módulo de Pickit para WooCommerce.
 * Version: 1.0.0
 * Author: VDFactory
 *
 * @package Pickit
 */

/*
 * Add my new menu to the Admin Control Panel
*/
 
add_action( 'admin_menu', 'pkt_Add_My_Admin_Link' );
add_action( 'wp_enqueue_scripts', 'dcms_load_dashicons_front_end' );

//Adding CSS
wp_register_style ( 'pickitconfig', plugins_url ( 'css/pkt-config-page.css', __FILE__ ) );
wp_enqueue_style( 'pickitconfig' );

// Add a new top level menu link to the ACP
function pkt_Add_My_Admin_Link()
{
    add_menu_page(
        'Pickit', // Title of the page
        'Pickit', // Text to show on the menu link
        'manage_options', // Capability requirement to see the link
        plugin_dir_path( __FILE__ ) . '/pkt-config-page.php' // The 'slug' - file to display when clicking the link
    );
}