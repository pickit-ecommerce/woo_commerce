<?php
/**
 * Plugin Name: Pickit
 * Description: Módulo de Pickit para WooCommerce.
 * Version: 1.0.0
 * Author: VDFactory
 *
 * @package Pickit
 */

if (isset($_POST['submit_pickit_global'])){

  $global_data = array(
    testing_mode => $_POST['pickit_testing_mode'],
    //titledom => $_POST['pickit_titledom'],
    //apk_r => $_POST['pickit_apikey_retailer'],
    apk_w => $_POST['pickit_apikey_webapp'],
    token_id => $_POST['pickit_token_id'],
    url_webs => $_POST['pickit_url_webservice'],
    url_webs_test => $_POST['pickit_url_webservice_test'],
    weight => $_POST['pickit_product_weight'],
    impos_av => $_POST['pickit_imposition_available'],
    estado_inicial => $_POST['pickit_estado_inicial'],
    //ship_price_opt_dom => $_POST['pickit_ship_price_opt_dom'],
    //ship_price_fijo_dom => $_POST['pickit_ship_price_fijo_dom'],
    //ship_price_porcentual_dom => number_format($_POST['pickit_ship_price_porcentual_dom'], 2),
    ship_price_opt_punto => $_POST['pickit_ship_price_opt_punto'],
    ship_price_fijo_punto => $_POST['pickit_ship_price_fijo_punto'],
    //Sólo toma dos decimales del float.
    ship_price_porcentual_punto => number_format($_POST['pickit_ship_price_porcentual_punto'], 2),
  );

  function pickit_global_config_insert($global_data) {

    global $wpdb;

    $table_name = $wpdb->prefix . 'woocommerce_pickit_global';
  
    $delete = $wpdb->query("TRUNCATE TABLE $table_name");

    $wpdb->insert(
      $table_name,
      array( 
        'pickit_testing_mode' => $global_data[testing_mode], 
        //'pickit_titledom' => $global_data[titledom],
        'pickit_apikey_webapp' => $global_data[apk_w], 
        'pickit_token_id' => $global_data[token_id], 
        'pickit_url_webservice' => $global_data[url_webs],
        'pickit_url_webservice_test' => $global_data[url_webs_test],
        'pickit_product_weight' => $global_data[weight],
        'pickit_imposition_available' => $global_data[impos_av],
        'pickit_estado_inicial' => $global_data[estado_inicial],
        //'pickit_ship_type' => $global_data[ship_type],
        //'pickit_ship_price_opt_dom' => $global_data[ship_price_opt_dom],
        //'pickit_ship_price_fijo_dom' => $global_data[ship_price_fijo_dom],
        //'pickit_ship_price_porcentual_dom' => $global_data[ship_price_porcentual_dom],
        'pickit_ship_price_opt_punto' => $global_data[ship_price_opt_punto],
        'pickit_ship_price_fijo_punto' => $global_data[ship_price_fijo_punto],
        'pickit_ship_price_porcentual_punto' => $global_data[ship_price_porcentual_punto],
      ) 
    );
  }
  pickit_global_config_insert($global_data);
}