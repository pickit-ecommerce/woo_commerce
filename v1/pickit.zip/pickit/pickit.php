<?php
/**
 * Plugin Name: Pickit
 * Description: Módulo de Pickit para WooCommerce.
 * Version: 1.0.0
 * Author: VDFactory
 *
 * @package Pickit
 */
include_once PICKIT_PATH . 'includes/pkt-class-utilities.php';

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Verifica que WooCommerce esté activo.
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

    define( 'PICKIT_PATH', plugin_dir_path( __FILE__ ) );
    define( 'PICKIT_URL', __FILE__ );
    
    require_once PICKIT_PATH . 'includes/pkt-sql-install.php';
    require_once PICKIT_PATH . 'includes/pkt-sql-uninstall.php';
    require_once PICKIT_PATH . 'includes/pkt-view.php';
    require_once PICKIT_PATH . 'includes/pkt-form-handler.php';
    require_once PICKIT_PATH . 'includes/pkt-ship-methods.php';
    require_once PICKIT_PATH . 'includes/pkt-thankyou.php'; 
    require_once PICKIT_PATH . 'includes/pkt-actions-and-filters.php';
}